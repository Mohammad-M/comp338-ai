package GUI;

public class quewe {
	List q;
	
	public quewe() {
		q = new List();
	}
	public void inq(Object o){
		q.addFirst(o);
	}
	public Object deq(){
		return q.removeFirst();
	}
	public int size(){
		return q.getlength();
	}
	public boolean empty() {
		return size()==0;
		
	}
	public boolean isin(Object o) {
		
		return q.isin(o);
	}
	
}
