package GUI;



public class lNode {
	Object element;
	lNode Next;
	public lNode(Object element) {
		super();
		this.element = element;
		
	}
}
