package GUI;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class AI_Contruler implements Initializable {
	@FXML
	Pane root = new Pane();
	@FXML
	Button ver = new Button();
	@FXML
	Button edge = new Button();
	@FXML
	Button clear = new Button();
	@FXML
	boolean verF = false;
	@FXML
	boolean edgeF = false;
	@FXML
	boolean clearF = false;
	@FXML
	public static Vertices data[] = new Vertices[200];

	private PrintWriter savetxt;
	private Scanner scan;
	@FXML
	Labeled startVertex;
	boolean BFsboolean;
	private boolean Vstart = false;
	private Vertices Vbegin;
	private boolean UCSboolean;

	public void BFS() {
		System.out.println("bfs");
		BFsboolean = true;
		Vstart = true;
		startVertex.setText("Pleas select start vertex ...");
		startVertex.setVisible(true);
	}

	public void UCS() {
		System.out.println("bfs");
		UCSboolean = true;
		Vstart = true;
		startVertex.setText("Pleas select start vertex ...");
		startVertex.setVisible(true);
	}

	public void clear() {
		BFsboolean = false;
		Vstart = false;
		UCSboolean = false;
		startVertex.setText("Pleas select start vertex ...");
		startVertex.setVisible(false);
		lNode n = alledgeDrow.getFirstNode();
		for (int i = 0; i < alledgeDrow.getlength(); i++) {
			((edge) n.element).line.setStroke(Color.DARKGREEN);
			n = n.Next;
		}
		alledgeDrow = new List();
		for (int i = 0; i < data.length; i++) {
			if (data[i] != null) {

				data[i].isUsed = false;
				data[i].parent = null;
				data[i].costEdge = 0;
			}
		}
		System.out.println("clear");

	}

	@FXML
	private void save() throws FileNotFoundException {
		File savedata = new File("files/data.txt");
		savetxt = new PrintWriter(savedata);
		for (int i = 1; i < data.length; i++) {
			if (data[i] != null) {
				String data1 = data[i].getVid() + "," + data[i].getName() + "," + data[i].getCenterX() + ","
						+ data[i].getCenterY();
				String data2 = new String();
				String tmp = new String();
				for (int j = 0; j < data[i].getCost().size(); j++) {
					edge tmpCost = data[i].getCost().get(j);
					tmp = tmpCost.getVid2() + ":" + tmpCost.getCost() + ",";
					data2 += tmp;
				}
				savetxt.println(data1 + "#" + data2);
			}

		}
		savetxt.close();

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// TODO Auto-generated method stub
		root.setOnMousePressed(e -> {
			if (verF) {
				TextInputDialog dialog = new TextInputDialog("Name Of city ");
				dialog.setTitle("Name Of city");
				dialog.setHeaderText("");
				dialog.setContentText("Please enter the name of City ");
				Optional<String> result = dialog.showAndWait();
				try {
					String name = result.get();
					int i = Vertices.vNum;
					data[i] = new Vertices(e.getX(), e.getY(), 5);
					data[i].setName(name);
					root.getChildren().add(data[i]);
				} catch (Exception ew) {
					// TODO: handle exception
				}
			}
		});

		ver.setOnAction(e -> {
			verF = true;
			edgeF = false;
			clearF = false;
		});
		clear.setOnAction(e -> {
			verF = false;
			edgeF = false;
			clearF = true;
		});

	}

	@FXML
	private void addEdgeFun() {
		verF = false;
		edgeF = true;
		clearF = false;
		Stage edgeStage = new Stage();
		GridPane Pane = new GridPane();
		Scene edgeScene = new Scene(Pane);
		ListView<listCity> cityOne = new ListView<listCity>();
		ListView<listCity> cityTwo = new ListView<listCity>();
		Button addEdge = new Button("Add Edge");
		TextField costValue = new TextField();
		Label c1 = new Label("City One");
		Label c2 = new Label("City Two");
		c1.setPrefWidth(340);
		c2.setPrefWidth(340);
		c1.setPrefHeight(30);
		c2.setPrefHeight(30);
		c1.setAlignment(Pos.CENTER);
		c2.setAlignment(Pos.CENTER);
		addEdge.setPrefWidth(340);
		costValue.setPromptText("Cost in Km");

		Pane.add(c1, 0, 0);
		Pane.add(c2, 1, 0);
		Pane.add(cityOne, 0, 1);
		Pane.add(cityTwo, 1, 1);
		Pane.add(addEdge, 1, 2);
		Pane.add(costValue, 0, 2);

		ObservableList<listCity> options = FXCollections.observableArrayList();
		ObservableList<listCity> options2 = FXCollections.observableArrayList();
		for (int i = 1; i < AI_Contruler.data.length; i++) {
			if (data[i] != null) {
				options.add(new listCity(data[i].getVid(), data[i].getName()));
			} else
				break;
		}

		for (int i = 1; i < AI_Contruler.data.length; i++) {
			if (data[i] != null) {
				options2.add(new listCity(data[i].getVid(), data[i].getName()));
			} else
				break;
		}
		cityOne.setItems(options);
		cityTwo.setItems(options2);
		addEdge.setOnAction(e -> {
			int v1 = cityOne.getSelectionModel().getSelectedItem().getVid();
			int v2 = cityTwo.getSelectionModel().getSelectedItem().getVid();
			double cost = Double.parseDouble(costValue.getText());
			// data[v1].getCost().add(new Cost(v2, cost));
			Line lineTmp = new Line(data[v1].getCenterX(), data[v1].getCenterY(), data[v2].getCenterX(),
					data[v2].getCenterY());
			root.getChildren().add(lineTmp);
		});
		edgeStage.setScene(edgeScene);
		File BZU_IMG_ICON = new File("files/img/icon.png");
		edgeStage.getIcons().add(new Image(BZU_IMG_ICON.toURI().toString()));
		edgeStage.setTitle("Add edge");
		edgeStage.setResizable(false);
		edgeStage.show();

	}

	@FXML
	public void readFile() {
		File info = new File("files/data.txt");
		try {
			int max = 0;
			scan = new Scanner(info);
			while (scan.hasNextLine()) {
				String line = scan.nextLine();
				String sp[] = line.split("#");
				String sp2[] = sp[0].split(",");
				int i = Integer.parseInt(sp2[0]);
				data[i] = new Vertices(Double.parseDouble(sp2[2]), Double.parseDouble(sp2[3]) + 15, 5, i, sp2[1]);
				data[i].setOnMouseMoved(e -> {
					data[i].setFill(Color.CYAN);
				});
				data[i].setOnMouseExited(e -> {
					data[i].setFill(Color.BLUE);
				});
				data[i].setOnMouseClicked(e -> {

					if (BFsboolean) {
						startVertex.setText("Pleas select end vertex ...");
						if (Vstart) {
							Vbegin = (Vertices) e.getSource();
							Vstart = false;
						} else {
							clear();
							BFSAlgorethim(Vbegin, (Vertices) e.getSource());
							BFSDrowingPath((Vertices) e.getSource());

							startVertex.setText("Pleas select start vertex ...");
							startVertex.setVisible(false);
						}
					}
					if (UCSboolean) {
						startVertex.setText("Pleas select end vertex ...");
						if (Vstart) {
							Vbegin = (Vertices) e.getSource();
							Vstart = false;
						} else {
							clear();
							UCSAlgorethim(Vbegin, (Vertices) e.getSource());
							UCSDrowingPath((Vertices) e.getSource());

							startVertex.setText("Pleas select start vertex ...");
							startVertex.setVisible(false);
						}
					}
				});

			}
			scan = new Scanner(info);
			while (scan.hasNextLine()) {
				String line = scan.nextLine();
				String sp[] = line.split("#");
				String sp2[] = sp[0].split(",");
				int i = Integer.parseInt(sp2[0]);

				if (i > max)
					max = i;

				if (sp.length > 1) {
					String sp3[] = sp[1].split(",");
					for (int j = 0; j < sp3.length; j++) {
						String sp4[] = sp3[j].split(":");

						double startX = data[i].getCenterX();
						double startY = data[i].getCenterY();
						double endX;
						double endY;
						double m = (data[Integer.parseInt(sp4[0])].getCenterY() - startY)
								/ (data[Integer.parseInt(sp4[0])].getCenterX() - startX);
						double angle = Math.atan(m);
						if (startX <= data[Integer.parseInt(sp4[0])].getCenterX()) {
							endX = data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle + Math.PI)
									+ data[Integer.parseInt(sp4[0])].getCenterX();
							startX += data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle);
							endY = data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle + Math.PI)
									+ data[Integer.parseInt(sp4[0])].getCenterY();
							startY += data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle);
						} else {
							endX = data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle)
									+ data[Integer.parseInt(sp4[0])].getCenterX();
							startX += data[Integer.parseInt(sp4[0])].getRadius() * Math.cos(angle + Math.PI);
							startY += data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle + Math.PI);
							endY = data[Integer.parseInt(sp4[0])].getRadius() * Math.sin(angle)
									+ data[Integer.parseInt(sp4[0])].getCenterY();
						}

						edge c = new edge(i, Integer.parseInt(sp4[0]), Double.parseDouble(sp4[1]), startX, startY, endX,
								endY);
						c.setOnMouseMoved(e -> {
							((edge) e.getSource()).l.setLayoutX(e.getX() - 26);
							((edge) e.getSource()).l.setLayoutY(e.getY() - 10);

							((edge) e.getSource()).l.setVisible(true);
						});
						c.setOnMouseExited(e -> {
							((edge) e.getSource()).l.setVisible(false);
						});
						data[i].getCost().add(c);
						data[Integer.parseInt(sp4[0])].getCost().add(c);
						root.getChildren().add(c);
					}
				}
			}
			Vertices.vNum = max + 1;

			for (int i = 1; i < data.length; i++) {
				if (data[i] != null) {
					root.getChildren().add(data[i]);
				} else
					break;
			}

			// for (int i = 1; i < data.length; i++) {
			// if(data[i]!= null){
			// for (int j = 0; j < data[i].getCost().size(); j++) {
			// Cost tmp = data[i].getCost().get(j);
			// double startX=data[i].getCenterX();
			// double startY=data[i].getCenterY();
			// double endX;
			// double endY;
			// double m = (data[tmp.getVid2()].getCenterY() - startY) /
			// (data[tmp.getVid2()].getCenterX() - startX);
			// double angle = Math.atan(m);
			// if (startX <= data[tmp.getVid2()].getCenterX()) {
			// endX = data[tmp.getVid2()].getRadius() * Math.cos(angle +
			// Math.PI) + data[tmp.getVid2()].getCenterX();
			// startX += data[tmp.getVid2()].getRadius() * Math.cos(angle);
			// endY = data[tmp.getVid2()].getRadius() * Math.sin(angle +
			// Math.PI) + data[tmp.getVid2()].getCenterY();
			// startY += data[tmp.getVid2()].getRadius() * Math.sin(angle);
			// } else {
			// endX = data[tmp.getVid2()].getRadius() * Math.cos(angle) +
			// data[tmp.getVid2()].getCenterX();
			// startX += data[tmp.getVid2()].getRadius() * Math.cos(angle +
			// Math.PI);
			// startY += data[tmp.getVid2()].getRadius() * Math.sin(angle +
			// Math.PI);
			// endY = data[tmp.getVid2()].getRadius() * Math.sin(angle) +
			// data[tmp.getVid2()].getCenterY();
			// }
			// //Line lineTmp = new Line(data[i].getCenterX(),
			// data[i].getCenterY(), data[tmp.getVid2()].getCenterX(),
			// data[tmp.getVid2()].getCenterY());
			// Line lineTmp = new Line( startX, startY, endX, endY);
			// root.getChildren().add(lineTmp);
			// }
			// }else
			// break;
			// }

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void UCSDrowingPath(Vertices source) {
		if (source.parent != null) {
			for (int i = 0; i < source.getCost().size(); i++) {
				edge e = source.getCost().get(i);
				if (e.getVid1() == source.parent.getVid()) {
					e.line.setStroke(Color.RED);
					alledgeDrow.addLast(e);
				} else if (e.getVid2() == source.parent.getVid()) {
					e.line.setStroke(Color.RED);
					alledgeDrow.addLast(e);
				}
			}
			System.out.println(source.getName());
			BFSDrowingPath(source.parent);
		}

	}

	private void UCSAlgorethim(Vertices vbegin2, Vertices end) {
		minHeap heap = new minHeap(200);
		vbegin2.costEdge = 0;
		Vertices temp = vbegin2;
		temp.isUsed = true;
		while (true) {
			if (temp.getVid() == end.getVid()) {
				System.out.println("done 2");
				break;
			} else {
				for (int i = 0; i < temp.getCost().size(); i++) {
					edge c = temp.getCost().get(i);
					Vertices v = data[c.getVid1()];

					if (temp.getVid() != v.getVid()) {
						if (!v.isUsed) {
							if(v.parent==null){
								v.parent = temp;
								v.edgeparent = c;
								v.costEdge = c.cost + v.parent.costEdge;
							}
							else{
								double a,b;
								a= c.cost + v.parent.costEdge;
								b= v.edgeparent.cost + v.parent.costEdge;
								if(b>a)
									v.parent = temp;
								v.costEdge = c.cost + v.parent.costEdge;
							}
							
							heap.insert(new Node(v));
							System.out.print(v.getName()+"--"+v.costEdge+" %% ");
						}
					} else {
						v = data[c.getVid2()];
						if (!v.isUsed) {	
							if(v.parent==null){
								v.parent = temp;
								v.edgeparent = c;
								v.costEdge = c.cost + v.parent.costEdge;
							}
							else{
								double a,b;
								a= c.cost + v.parent.costEdge;
								b= v.edgeparent.cost + v.parent.costEdge;
								if(b>a)
									v.parent = temp;
								v.costEdge = c.cost + v.parent.costEdge;
							}
							
							
							heap.insert(new Node(v));
							System.out.print(v.getName()+"--"+v.costEdge+" %% ");
						}
					}

				}
				if(heap.size==0)
					break;
				System.out.println();
				
				temp = heap.deleteMin().element;
				temp.isUsed = true;
				System.out.println("temp = "+temp.getName());
			}

		}

	}

	List alledgeDrow = new List();

	private void BFSDrowingPath(Vertices source) {
		if (source.parent != null) {
			for (int i = 0; i < source.getCost().size(); i++) {
				edge e = source.getCost().get(i);
				if (e.getVid1() == source.parent.getVid()) {
					e.line.setStroke(Color.RED);
					alledgeDrow.addLast(e);
				} else if (e.getVid2() == source.parent.getVid()) {
					e.line.setStroke(Color.RED);
					alledgeDrow.addLast(e);
				}
			}
			System.out.println(source.getName());
			BFSDrowingPath(source.parent);
		}
	}

	public void BFSAlgorethim(Vertices begin, Vertices end) {
		quewe q = new quewe();
		q.inq(begin);

		while (!q.empty()) {
			Vertices v = (Vertices) q.deq();
			v.isUsed = true;
			for (int i = 0; i < v.getCost().size(); i++) {
				Vertices d = data[v.getCost().get(i).getVid1()];
				if (d.getVid() != v.getVid()) {
					if (d == end) {
						d.parent = v;
						System.out.println("find");
						return;
					} else {
						if (!d.isUsed) {
							q.inq(d);
							if(d.parent==null)
								d.parent = v;
						}
					}
				} else {
					d = data[v.getCost().get(i).getVid2()];
					if (d == end) {
						d.parent = v;
						System.out.println("find");
						return;
					} else {
						if (!d.isUsed) {
							q.inq(d);
							if(d.parent==null)
								d.parent = v;
						}
					}
				}
			}
		}

	}

	public void about() {
		Alert infoMsg = new Alert(AlertType.INFORMATION);
		infoMsg.setContentText(
				"This Is The Artificial intelligence  project \nDone by  Waseem Awashra \nCourse Instructor Dr. Mustafa Jarrar");
		infoMsg.show();
	}
}
